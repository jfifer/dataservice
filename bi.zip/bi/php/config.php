<?php

/*********     config.php    ***********
 *
 * Init variables for the BI
 * Author: Mike Marshall
 * Created At: 2016 09 15
 *
 */


/* [DATABASE CONFIG] */




//admin
$HOST   ='172.16.127.63';
$DBUSER ='root';
#$DBPORT=3306;
$DBNAME ='mysql';
$DBPWD  ='root';

//itop
$iHOST = 'localhost';
$iDBUSER = 'root';
$iDBNAME = 'itop';
$iDBPWD = 'd8agod';


?>
